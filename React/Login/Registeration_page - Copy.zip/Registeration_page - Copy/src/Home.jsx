import React from 'react'

const Home = () => {
  const getUser = JSON.parse(localStorage.getItem('loginUser'))
  console.log(getUser)
  return (
    <>
    <h1>Welcome {getUser.username}</h1>
    </>
  )
}

export default Home